package com.example.store.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
